\ Application
module[ application"

include device.fs

: main ( --)   begin  service-usb  again ;

]module
