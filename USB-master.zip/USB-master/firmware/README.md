# Edit Makefile

1. Change variable FORTH to SwiftForth or GForth binary.

2. Compile the firmware and provide the MIF to Modelsim and Quartus II

```shell
make sim syn
```
